export const CAR_LIST_REQUEST = 'auth/car/inform';
export const GET_CAR_LIST_SUCCESS = 'auth/car/getinfo/success';
export const CAR_STATE_REQUEST = 'auth/car/state/request';
export const GET_CAR_STATE_SUCCESS = 'auth/car/getstate/success';
