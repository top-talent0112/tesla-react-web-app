import React, { Component } from 'react';

class Contact extends Component {
  render() {
    return (
      <div>
        <h3>Email:</h3>
        <p>placeholder@gmail.com</p>
        <h3>YouTube:</h3>
        <p><a href='https://youtube.com/xxxx'>https://youtube.com/xxxx</a></p>

      </div>
    );
  }
}

export default Contact;
